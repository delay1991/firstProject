package co.friend; //회사별 패키지 ex. 유니크도메인_역순 friend.co...

import co.friend.view.FriendcliApp;

public class AppMain {
	public static void main(String[] args) {
		FriendcliApp app = new FriendcliApp();
		app.start();
	}
}
